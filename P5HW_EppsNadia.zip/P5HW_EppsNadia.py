#P5HW
#25 November 2023
#CTI-110 P5HW - Math Quiz
#Nadia Epps
#

print("Welcome to Math Quiz")

import random
random1 = random.randint(1, 250)
random2 = random.randint(1, 250)

def ask():
    global random1
    global random2

print("MAIN MENU")
print("--------------------")
while True:
    print("1. Adding Random Numbers")
    print("2. Subtracting Random Numbers")
    print("3. Exit")
    
user_choice = input("Please choose one of the menu options: ")

if user_choice == "1":
    num1 = random.randint(1, 100)
    num2 = random.randint(1, 100)
    answer = num1 + num2
     
    print(f"\n{num1} +{num2}")
    user_answer = int(input("Enter answer. "))

if user_answer == answer:
    print("Congratulations!!!! Your answer is correct. ")
    score += 1
elif user_answer > answer:
    print("Try again")
    print("Sorry, guess is too high.")
else:
    print("Try again")
    print("Sorry, guess is too low.")
if user_choice == "2":
    num1 = random.randint(1, 100)
    num2 = random.randint(1, 100)
    answer = num1 - num2

    print(f"\n{num1} - {num2}")
    user_answer = int(input("Enter answer. "))
        
if user_answer == answer:
    print("Congratulations!!!! Your answer is correct.")
    score += 1
elif user_answer > answer:
    print("Try again")
    print("Sorry, guess is too high.")

else:
    print("Try again")
    print("Sorry, guess is too low.")
        
if user_choice == '3':
    print("Thank you for playing...")
    print("Bye!!")

else:
    print("Invalid choice. Please try again.")

	







##    if user_choice == '3':
##        print("Thank you for playing...")
##        print("Bye!!")
##
##    if user_choice in {'1', '2'}:
##        num1 = random.randint(1, 10)
##        num2 = random.randint(1, 10)
##        user_answer = 0
##
##    if user_choice == '1':
##        print(f" {random1} + {random2}")
##        user_answer = random1 + random2
##    elif user_choice == '2':
##        print(f" {random1} - {random2}")
##        user_answer = random1 - random2
##
##
    

    


